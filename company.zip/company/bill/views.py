
from traceback import print_tb
from django.shortcuts import render, HttpResponse, redirect
from django.http import HttpResponseRedirect
from inventory.models import Add_product
from services.models import Add_package, Add_service
import json
from datetime import date
from .models import Invoice,Bill
from bill.htmlpdf import save_pdf, save_pdf_thermal
from django.http import FileResponse
import os
from django.conf import settings
from django.db.models import Q
from django.core.serializers.json import DjangoJSONEncoder
from client.models import Add_voucher_range, Add_voucher
from crmemail.pyemail import file_email, text_mail
from client.models import Add_client
from django.contrib import messages
from django.contrib.auth.decorators import login_required
import hashlib


# Create your views here.
@login_required(login_url='/')
def bill(request):
    yy = date.today()
    yy = yy.strftime("%y")

    total_invoice = 0
    total_invoice = Invoice.objects.all()
    total_invoice = len(total_invoice)
    
    if total_invoice == None or total_invoice == 0:
        invoice = yy+"0001"
    else:
        invoices =  Invoice.objects.latest("invoice")
        invoices = str(invoices)
        invoice = int(invoices) + 1
        # invoices = invoices[:-1]
        # invoice = invoices+str(lastnum + 1)

    plaintext = str(invoice).encode()
    d = hashlib.sha256(plaintext)
    hash = d.digest()
    hash = str(hash)
    dic={
        "invoice": invoice,
        "total_invoices": total_invoice,
        "invoice_hash": hash
    }
    return render(request, 'bill/bill.html', dic)

@login_required(login_url='/')
def send_data(request):
    if request.method == "POST":
        Prcode = Add_product.objects.values_list('product_code', flat=True)
        Prname = Add_product.objects.values_list('product_name', flat=True)
        Prprice = Add_product.objects.values_list('product_unit_price', flat=True)

        Svccode = Add_service.objects.values_list('service_code', flat=True)
        Svcname = Add_service.objects.values_list('service_name', flat=True)
        Svcprice = Add_service.objects.values_list('service_price', flat=True)

        Pkgcode = Add_package.objects.values_list('package_code', flat=True)
        Pkgname = Add_package.objects.values_list('package_name', flat=True)
        Pkgprice = Add_package.objects.values_list('package_price', flat=True)

        pro_data = []
        svc_data = []
        pkg_data = []
        for i,v in enumerate(Prcode):
            tu = (v,Prname[i], Prprice[i])
            pro_data.append(tu)
        for i,v in enumerate(Svccode):
            tu = (v,Svcname[i], Svcprice[i])
            svc_data.append(tu)
        for i,v in enumerate(Pkgcode):
            tu = (v,Pkgname[i], Pkgprice[i])
            pkg_data.append(tu)

        dic = {}
        
        dic["data"] = pro_data + svc_data + pkg_data
        dataJson = json.dumps(dic)
        
        return HttpResponse(dataJson, content_type="application/json")


@login_required(login_url='/')
def get_data(request):
   
    if request.method == "POST":
        invoice = request.POST["invoice_number"]
        email = request.POST["client_email"]
        cname = request.POST["clitent_name"]
        date = request.POST["bill_date_time"]
        code = request.POST.getlist("send_code[]")
        pname = request.POST.getlist("pname[]")
        unitprice = request.POST.getlist("unitprice[]")
        qty = request.POST.getlist("qty[]")
        rowtotal = request.POST.getlist("rowtotal[]")
        total = request.POST["total"]
        discount = request.POST["discount"]
        gst = request.POST["gst"]
        voucher = request.POST["voucher"]
        grandtotal = request.POST["grandtotal"]
        voucher_data = Add_voucher_range.objects.all().values()[0]
        
        if (int(voucher_data['vocher_from']) <= int(float(grandtotal))) or int(float(voucher)) !=0:
            
            
            new_invoice = Invoice(invoice=invoice, client_email=email, client_name=cname,date=date, total=total, discount=discount, gst=gst, voucher=voucher, grand_total=grandtotal)
            new_invoice.save()
            if Add_voucher.objects.filter(client_email = email).count()!=0:
                
                curent_voucher = Add_voucher.objects.filter(client_email = email).values()[0]['client_voucher_balance']
                Add_voucher.objects.filter(client_email = email).update(client_voucher_balance=curent_voucher-int(voucher))
            
            else:
                
                new_voucher = Add_voucher(client_name=cname, client_email = email, client_voucher_balance=Add_voucher_range.objects.values()[0]['voucher_value'])
                new_voucher.save()
        else:

            new_invoice = Invoice(invoice=invoice, client_email=email, client_name=cname,date=date, total=total, discount=discount, gst=gst, voucher=voucher, grand_total=grandtotal)
            new_invoice.save()

        for indx, value in enumerate(code):
           
            new_bill = Bill(invoice=invoice, code=value, product_name=pname[indx], unitprice=unitprice[indx], qty=qty[indx], total=rowtotal[indx])
            new_bill.save()

        dics = {"message":"Save"}
        
        invoices =  Invoice.objects.latest("invoice")
        invoce_data = Invoice.objects.filter(invoice=str(invoices)).values_list()
        bill_data = Bill.objects.filter(invoice=str(invoices)).values_list()
        dic = {}
        temp=[]
        b = []
        l=1
        name_list = ["Total: ","Discount: ","GST: ","Voucher: ", "Grand Total: "]
        invoice_name = ["Invoice: ", "Email: ", "Name: ", "Date&Time: "]
        inv_data = list(list(invoce_data[0]))   
        dic["total"] = inv_data[4:]
        dic["name_list"] = name_list
        send_tn = zip(invoice_name,inv_data[:4])
        dic["invoice_data"] = send_tn
        bill = list(bill_data)
        for j in bill:
            temp.append(l)
            for indx,val in enumerate(j):
                if indx > 1:
                    temp.append(val)
            b.append(temp)
            l = l+1
            temp=[]
        dic["bill"]=b

        filename, status = save_pdf_thermal(dic, filename=str(invoice))
        if not status:
            print("wrong file")
        return HttpResponse(json.dumps(dics, cls=DjangoJSONEncoder), content_type="application/json")


@login_required(login_url='/')
# search data
def search_data(request):
    dic = {}
    if request.method == "POST":
        query = request.POST['searchbox']
        if query != "all":
            result = Invoice.objects.filter(Q(invoice__contains=query) | 
            Q(client_email__contains=query) | 
            Q(client_name__contains=query) | 
            Q(date__contains=query) | 
            Q(total__contains=query) | 
            Q(discount__contains=query) |
            Q(gst__contains=query) | 
            Q(voucher__contains=query) |
            Q(grand_total__contains=query)).values_list()

            if len(result) == 0:
                dic = {'error':'No Data Found!'}
            else:
                dumpdata = []
                for data in result:
                    dumpdata.append(list(data))
                dic = {'result_data':dumpdata, 'error':'None'}

            return HttpResponse(json.dumps(dic, cls=DjangoJSONEncoder), content_type="application/json")
        else:
            alldata = list(Invoice.objects.all().values_list())
            if len(alldata) != 0:
                dic = {'result_data':alldata, 'error':'None'}
            else:
                dic = {'error':'No Data Found!'}
            return HttpResponse(json.dumps(dic, cls=DjangoJSONEncoder), content_type="application/json")
    return HttpResponse(json.dumps(dic, cls=DjangoJSONEncoder), content_type="application/json")

@login_required(login_url='/')
def email_invoice(request):
    invoices =  Invoice.objects.latest("invoice")
    invoce_data = Invoice.objects.filter(invoice=str(invoices)).values_list()
    filepath = os.path.join(settings.MEDIA_ROOT, 'pdffile/'+str(invoices)+'.pdf')
    rslt = file_email("Bill from silksalon", "This is a your bill file.", [invoce_data[0][1]], filepath)
    if rslt == "Email send successfully.":
        messages.success(request, "Email Send Successfully!")
        dic={'message':"successful"}
    else:
        dic={'message':"mail not send"}
        messages.error(request, "Email Not Send!")

    return redirect('bill')


@login_required(login_url='/')
def autocompletdata(request):
    data = request.POST['clientemail']
    email = list(Add_client.objects.values_list('client_email', flat=True).all())
    name = list(Add_client.objects.values_list('client_name', flat=True).all())
    dic = {'email': email, 'name':name}
    return HttpResponse(json.dumps(dic), content_type="application/json")

@login_required(login_url='/')
def getvoucher(request):
    data = request.POST['clientemail']
    result = list(Add_voucher.objects.filter(client_email=data).values_list('client_voucher_balance', flat=True))
    dic = {'result':result}
    return HttpResponse(json.dumps(dic), content_type="application/json")