from django.shortcuts import redirect, render, HttpResponse
from inventory.models import Add_product
from .models import Add_service, Add_package
import json
from django.db.models import Q
from django.contrib import messages
from django.core.serializers.json import DjangoJSONEncoder
from django.contrib.auth.decorators import login_required


# Create your views here.
@login_required(login_url='/')

def services(request):
    return render(request, 'services/services.html')


@login_required(login_url='/')

def product_list(request):
    code = Add_product.objects.values_list('product_code', flat=True)
    name = Add_product.objects.values_list('product_name', flat=True)
    
    dic = []
    send_data ={}
    for i,v in enumerate(code):
        zip_data = (v, name[i])
        dic.append(zip_data)
    send_data["list"] = dic
    return HttpResponse(json.dumps(send_data), content_type="application/json")



@login_required(login_url='/')

def service_list(request):
    code = Add_service.objects.values_list('service_code', flat=True)
    name = Add_service.objects.values_list('service_name', flat=True)
    print(code)
    dic = []
    send_data ={}
    for i,v in enumerate(code):
        zip_data = (v, name[i])
        dic.append(zip_data)
    send_data["list"] = dic
    return HttpResponse(json.dumps(send_data), content_type="application/json")




@login_required(login_url='/')

def add_service(request):
    service_code = request.POST['servicecode']
    service_name = request.POST['servicename']
    service_products = request.POST.getlist('itemcode')
    service_products = [ i.replace('/', '') for i in service_products if '/' in i ]
    service_products = ", ".join( repr(e) for e in service_products )
    print(service_products)
    service_price = request.POST['serviceprice']
    if Add_service.objects.filter(service_code=service_code).exists():
        messages.error(request, "Service Data Already Exits!")
        return redirect('services')
    else:
        service_code = "SVC"+service_code
        new_service = Add_service(service_code=service_code, service_name=service_name, service_product= service_products, service_price=service_price)
        new_service.save()
        messages.success(request, "Service Data Save Successfully!")
        return redirect('services')



@login_required(login_url='/')

def add_package(request):
    package_code = request.POST['packagecode']
    package_name = request.POST['packagename']
    package_services = request.POST.getlist('itemcode')
    package_services = [ i.replace('/', '') for i in package_services if '/' in i ]
    package_services = ", ".join( repr(e) for e in package_services )
    package_price = request.POST['packageprice']
    if Add_package.objects.filter(package_code=package_code).exists():
        messages.error(request, "Package Data Already Exits!")
        return redirect('services')
    else:
        package_code = "PKG"+package_code
        new_service = Add_package(package_code=package_code, package_name=package_name, package_services= package_services, package_price=package_price)
        new_service.save()
        messages.success(request, "Package Data Save Successfully!")
        return redirect('services')




@login_required(login_url='/')

def search_data(request):
    if request.method == "POST":
        query = request.POST['searchbox']
        if query != "all":
            result_service = Add_service.objects.filter(Q(service_code__contains=query) | 
            Q(service_name__contains=query) | 
            Q(service_product__contains=query) | 
            Q(service_price__contains=query)).values_list()
            result_package = Add_package.objects.filter(Q(package_code__contains=query) | 
            Q(package_name__contains=query) | 
            Q(package_services__contains=query) | 
            Q(package_price__contains=query)).values_list()
            result = list(result_service) + list(result_package)
            dumpdata = []
            for data in result:
                dumpdata.append(list(data))

            service_count = len(result_service)
            package_count = len(result_package)
            dic = {'result_data':dumpdata, 'service_count':service_count,'package_count':package_count}

            return HttpResponse(json.dumps(dic, cls=DjangoJSONEncoder), content_type="application/json")
        else:
            service_list = list(Add_service.objects.all().values_list())
            package_list = list(Add_package.objects.all().values_list())
            alldata = list(service_list + package_list)
            
            dic = {'result_data':alldata}
            return HttpResponse(json.dumps(dic, cls=DjangoJSONEncoder), content_type="application/json")
    return redirect('inventory')


@login_required(login_url='/')

def edit_service(request):
    if request.method == "POST":
        code = request.POST['code']
        name = request.POST['name']
        servpro = request.POST['servpro']
        price = request.POST['price']
        # print(code, name, servpro, price)
        if Add_service.objects.filter(service_code=code).exists():
            Add_service.objects.filter(service_code=code).update(service_name=name, service_product=servpro, service_price=price)
        else:
            Add_package.objects.filter(package_code=code).update(package_name=name, package_services=servpro, package_price=price)
    return redirect('services')