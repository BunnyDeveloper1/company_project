from ast import In
from multiprocessing.spawn import import_main_path
from django.shortcuts import render
from django.db.models import Count
from datetime import datetime
import json

from client.models import Add_client
from bill.models import Invoice
from inventory.models import Add_product,Add_Catagories
from services.models import Add_service, Add_package
from marketing.models import Mrkt_client
from expenses.models import Expenses
from django.contrib.auth.decorators import login_required


# Create your views here.

@login_required(login_url='/')
def index(request):

    if request.user.is_authenticated:
        dic = {}
        if request.user.is_staff:
            cost = list(Expenses.objects.values_list('expenses_cost', flat=True).all())
            cost = sum(cost)
            dic['expenses'] = cost

            today_cost = Expenses.objects.values_list('expenses_cost', flat=True).filter(date=datetime.today().now())
            dic['today_expenses'] = sum(today_cost)
            
            today_invoice_cost = Invoice.objects.values_list('grand_total', flat=True).filter(date=datetime.today().now())
            dic['today_invoice_earning'] = sum(today_invoice_cost)
            dic['today_earning'] = sum(today_invoice_cost) - sum(today_cost)
            year = datetime.today().now()
            year = year.year
            earning = []
            expenses_total = []
            for i in range(1,13):
                if i < 10:
                    total = list(Invoice.objects.values_list('grand_total', flat=True).filter(date__range=[str(year)+"-0"+str(i)+"-"+"01", str(year)+"-0"+str(i)+"-"+"28"]))
                    total_expenses = list(Expenses.objects.values_list('expenses_cost', flat=True).filter(date__range=[str(year)+"-0"+str(i)+"-"+"01", str(year)+"-0"+str(i)+"-"+"28"]))
                else:
                    total = list(Invoice.objects.values_list('grand_total', flat=True).filter(date__range=[str(year)+"-"+str(i)+"-"+"01", str(year)+"-"+str(i)+"-"+"28"]))
                    total_expenses = list(Expenses.objects.values_list('expenses_cost', flat=True).filter(date__range=[str(year)+"-"+str(i)+"-"+"01", str(year)+"-"+str(i)+"-"+"28"]))


                total = sum(total)
                total_expenses = sum(total_expenses)
                earning.append(total)
                expenses_total.append(total_expenses)
                total = 0
                total_expenses = 0
            dic['total_earning_sum'] = json.dumps(earning)
            dic['expenses_total_sum'] = json.dumps(expenses_total)

            
            dic['clients'] = Add_client.objects.all().count()
            dic['female_clients'] = Add_client.objects.filter(client_gender="female").count()
            dic['male_clients'] = Add_client.objects.filter(client_gender="male").count()
            dic['green_client'] = len(list(Invoice.objects.values_list('client_email').annotate(green_client_count=Count('client_email')).exclude(green_client_count=1)))
            dic['green_client_list'] = list(Invoice.objects.values_list('client_name').annotate(green_client_count=Count('client_email')).exclude(green_client_count=1))
            dic['product'] = Add_product.objects.all().count()
            dic['categories'] = Add_Catagories.objects.all().count()
            dic['services'] = Add_service.objects.all().count()
            dic['packages'] = Add_package.objects.all().count()
            dic['invoice'] = Invoice.objects.all().count()
            month_start = datetime.today().replace(day=1)
            dic['month_invoice'] = Invoice.objects.filter(date__range=[month_start, datetime.today().now()]).count()
            dic['leads'] = Mrkt_client.objects.all().count()
            dic['today_leads'] = Mrkt_client.objects.filter(date = datetime.today().now()).count()
        
        
        
        return render(request, 'dashboard/dashboard.html', dic)