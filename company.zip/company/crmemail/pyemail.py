from django.conf import settings
from django.core.mail import send_mail, BadHeaderError, EmailMessage
import mimetypes

def text_mail(subject, message, to_email):
      if subject and message:
        try:
            send_mail(subject, message, settings.EMAIL_HOST_USER, to_email)
        except BadHeaderError:
            return False

def file_email(subject, message, to_email, file):
    try:
        mail = EmailMessage(subject, message, settings.EMAIL_HOST_USER, to_email)
        mail.attach_file(file)
        mail.send()
        return 'Email send successfully.'
    except Exception as e:
        return 'Somthing Wrong!'+str(e)

def file_inmemory_email(subject, message, to_email, file):
    try:
        mail = EmailMessage(subject, message, settings.EMAIL_HOST_USER, to_email)
        
        file.open()
        mail.attach(file.name, file.read(), file.content_type)
        file.close()
        mail.send()
        return 'Email send successfully.'
    except Exception as e:
        return 'Somthing Wrong!'+str(e)

