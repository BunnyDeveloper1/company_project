var mails = [];

$(document).on('click', '#clientemail', function (e) {
  e.preventDefault();
  if(document.getElementById('clientemail').value == ""){
    document.getElementById('voucher_tb').value = 0;
    document.getElementById('clientname').value = "";
  }

  $.ajax({
    type: 'POST',
    url: "autocompletdata/",
    content_type: "application/json",
    data:
    {
      clientemail: $("#clientemail").val(),
      csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
    },
    success: function (responsed) {

      $(function () {
        $("#clientemail").autocomplete({
          source: responsed.email,
          select: function (event, ui) {
            document.getElementById('clientname').value = responsed.name[responsed.email.indexOf(ui.item.label)];
            $.ajax({
              type: 'POST',
              url: "getvoucher/",
              content_type: "application/json",
              data:
              {
                clientemail: ui.item.label,
                csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
              },

              success:function(responsed){
                console.log(responsed.result[0]);
                if(responsed.result[0] != null){
                document.getElementById('voucher_tb').value = responsed.result[0];

                }
                else{
                document.getElementById('voucher_tb').value = 0;
                }
              
              }
            })
          }
        });
      });
    }
  })
})

