from django.contrib import admin
from marketing import models
# Register your models here.
admin.site.register(models.Mrkt_client)