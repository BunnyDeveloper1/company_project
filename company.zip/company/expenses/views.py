from django.shortcuts import render
from .models import Expenses
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required(login_url='/')

def expenses(request):
    return render(request, 'expenses/expenses.html')
    pass


@login_required(login_url='/')

def save_expenses(request):
    expname = request.POST['expensesname']
    expcost = request.POST['expensescost']
    new_expenses = Expenses(expenses_name=expname, expenses_cost=expcost)
    new_expenses.save()
    messages.success(request, "Expenses Data Save")
    return render(request, 'expenses/expenses.html')