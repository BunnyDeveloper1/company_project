from django.db import models


# Create your models here.
# add client models table

class Add_client(models.Model):

    client_name = models.CharField(max_length=40)
    client_email = models.EmailField(max_length=200, primary_key=True)
    client_phone_number = models.IntegerField(default="None")
    client_whatsapp_number = models.IntegerField(default="None")
    client_gender = models.CharField(max_length=10 ,default="None")
    
    def __str__(self):
        return self.client_name

class Add_voucher(models.Model):

    client_name = models.CharField(max_length=40)
    client_email = models.EmailField(max_length=200, primary_key=True)
    client_voucher_balance = models.IntegerField()
    

    def __str__(self):
        return self.client_name

class Add_voucher_range(models.Model):
    vocher_name = models.CharField(max_length=10,  default="Voucher")
    vocher_from = models.IntegerField()
    vocher_to = models.IntegerField()
    voucher_value = models.IntegerField(default=0)

    def __str__(self):
        return self.vocher_name


