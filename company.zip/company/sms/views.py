from django.shortcuts import render, redirect
from .models import SenderId, TemplateId

# Create your views here.
def sms(request):

    sender_id = list(SenderId.objects.values_list('sendid'))
    msg_template = list(TemplateId.objects.values_list('template'))
    dic = {}
    senderid =[]
    template_msg = []
    for o in sender_id:
        senderid.append(o[0])
    for o in msg_template:
        template_msg.append(o[0])
    dic['sender_id'] = senderid
    dic['template_msg'] = template_msg
    return render(request, 'sms/sms.html', dic)

def save_sender_id(request):
    sender_id = request.POST['senderid']
    new_sender_id =  SenderId(sendid=sender_id)
    new_sender_id.save()
    return redirect('sms')

def template_id(request):
    message_id = request.POST['messageid']
    message_template = request.POST['message_template']
    
    new_template = TemplateId(message_id = message_id, template = message_template)
    new_template.save()
    return redirect('sms')

def send_sms(request):
    contact = request.POST.getlist('contact')
    print(contact)
    return redirect('sms')