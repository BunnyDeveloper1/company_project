from unicodedata import name
from . import views
from django.urls import path

urlpatterns =[
    path('', views.client, name='client'),
    path('add_client/', views.add_client, name='add_client'),
    path('search_data/', views.search_data, name='search_data'),
    path('edit_client/', views.edit_client, name='edit_client'),
    path('search_voucher_data/', views.search_voucher_data, name='search_voucher_data/'),
    path('edit_voucher/', views.edit_voucher, name='edit_voucher/'),

]