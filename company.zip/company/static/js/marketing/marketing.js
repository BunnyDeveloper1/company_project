function modify(val){
    var row = val.parentNode.parentNode;
    document.getElementById("eclientname").value = row.cells[1].innerHTML;
    document.getElementById("eclientemail").value = row.cells[2].innerHTML;
    document.getElementById("ephonenumber").value = row.cells[3].innerHTML;
    clientstatus = row.cells[4].innerHTML;
    if(clientstatus.localeCompare("start")==0){
        document.getElementById("start").checked = true;
    }
    else if(clientstatus.localeCompare("bottletop")==0){
        document.getElementById("bottletop").checked = true;
    }
    else{
        document.getElementById("bottlein").checked = true;
    }

}



// search

$(document).on('submit', '#search_form', function (e) {
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: "search_data/",
        content_type: "application/json",
        data:
        {
            searchbox: $("#searchbox").val(),
            csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            let count = 0;
            let start = 0;
            let bottletop = 0;
            $("#search_td_data").empty();
            $("#todayleads-tab").removeClass('active');
            $("#search-tab").addClass('active');
            if (responsed.error.localeCompare('None') == 0) {
              
                    $.each(responsed.result_data, function (index, value) {
                        console.log(value)
                        count = count + 1;
                        if (value[4] == "start") {
                            start = start + 1;
                        }
                        else if(value[4]=="bottletop"){
                            bottletop = bottletop + 1;
                        }
                        html_text = "<tr><td>" + value[0] + "</td><td>" + value[1] + "</td><td>" + value[2] + "</td><td>" + value[3] + "</td><td>" + value[4] + "</td><td><a href='#' onclick='modify(this);' data-bs-toggle='modal' data-bs-target='#edit_model' id='row" + count + "'>Modify</a></tr>"

                        dump = $("#search_td_data");
                        dump.append(html_text);

                    })


                    $('#total').html(count);
                    bottlein = (count) - (bottletop + start);
                    $('#bottlehead').html(bottletop);
                    $('#inbottle').html(bottlein);
                    $('#start').html(start);
                    count = 0;

            }
            else{
                alert(responsed.error)
            }


        }
    })
});



// search date

$(document).on('submit', '#search_date_form', function (e) {
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: "search_data/",
        content_type: "application/json",
        data:
        {
            searchbox: $("#datesearchbox").val(),
            csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            let count = 0;
            let start = 0;
            let bottletop = 0;
            $("#search_td_data").empty();
            $("#todayleads-tab").removeClass('active');
            $("#search-tab").addClass('active');
            if (responsed.error.localeCompare('None') == 0) {
              
                    $.each(responsed.result_data, function (index, value) {
                        console.log(value)
                        count = count + 1;
                        if (value[4] == "start") {
                            start = start + 1;
                        }
                        else if(value[4]=="bottletop"){
                            bottletop = bottletop + 1;
                        }
                        html_text = "<tr><td>" + value[0] + "</td><td>" + value[1] + "</td><td>" + value[2] + "</td><td>" + value[3] + "</td><td>" + value[4] + "</td><td><a href='#' onclick='modify(this);' data-bs-toggle='modal' data-bs-target='#edit_model' id='row" + count + "'>Modify</a></tr>"

                        dump = $("#search_td_data");
                        dump.append(html_text);

                    })


                    $('#total').html(count);
                    bottlein = (count) - (bottletop + start);
                    $('#bottlehead').html(bottletop);
                    $('#inbottle').html(bottlein);
                    $('#start').html(start);
                    count = 0;

            }
            else{
                alert(responsed.error)
            }


        }
    })
});