// ajax for get a list of product and catagories
$(document).on('click', '#createcategories-tab', function (e) {
  e.preventDefault();
  $.ajax({
    type: 'POST',
    url: "get_data/",
    content_type: "application/json",
    data:
    {
      csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
    },
    success: function (responsed) {
      $("#product_list").empty();
      $("#show_catagories").empty();
      $("#addproduct-tab").removeClass('active');
      $("#package-tab").addClass('active');
      // this  each loop for product list
      $.each(responsed.list, function (response, value) {
        val1 = value[0];
        val2 = value[1];
        dump = $('#product_list');
        dump.append('<div class="row"><div class="col"><input type="checkbox" name="itemcode" value=' + val1 + '/> &nbsp;&nbsp;&nbsp;&nbsp;' + val1 + '</div><div class="col">' + val2 + '</div>');
        dump.append();
      }
      )
      var i = 0;
      // this each loop for catagories
      $.each(responsed.catagories, function (response, data) {
        catagorie_name = data.catagorie_name;

        txt = '';
        dump = $('#show_catagories'); //get the div 
        dump.append('<div class="row row-cols-1 row-cols-md-3 g-4 overflow-auto" id="cardgroup"></div>'); //crate a row wrapper and append it in div
        card = $('#cardgroup'); // get the div
        txt = '<div class="col"> <div class="card border-primary mb-3" style="max-width: 18rem;">\
            <div class="card-header"> <b>Catagorie Name</b>: '+ catagorie_name + '</div>\
            <div class="card-body">\
            <h5 class="card-title">List Of Product</h5>\
            <table class="table" >\
            <thead>\
            <tr>\
              <td>\
              Code\
              </td>\
              <td>\
              Name\
              </td>\
              <td>\
              Qty\
              </td>\
            <tr>\
            <tbody id="datashow'+ i + '">\
            </tbody>\
            </table>\
            </div></div></div>'; // create a box
        card.append(txt); // append a div

        $.each(data.data_list, function (idx, val) {

          tt = '<tr>\
              <td>\
              '+ val[0] + '\
              </td>\
              <td>\
              '+ val[1] + '\
              </td>\
              <td>\
              '+ val[2] + '\
              </td>\
              </tr>'
          $('#datashow' + i + '').append(tt);
        })
        i = i + 1;
      })
    }
  })
});


// search the product 

$(document).on('submit', '#search_form', function (e) {
  e.preventDefault();
  $.ajax({
    type: 'POST',
    url: "search_data/",
    content_type: "application/json",
    data:
    {
      searchbox: $("#searchbox").val(),
      csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
    },
    success: function (responsed) {
      console.log(responsed)
      var count = 0;
      $('#td_data').empty();
      $('#total').empty();
      $('#total_liquid').empty();
      $('#total_solid').empty();
      var liquid = 0;
      if(responsed.error.localeCompare('None')==0){
      $.each(responsed.result_data, function (index, value) {
        if (value[6].localeCompare('liquid') == 0) {
          liquid = liquid + 1;
        }

        count = count + 1;
        html_text = "<tr>\
                              <td>"+ count + "</td>\
                              <td>"+ value[1] + "</td>\
                              <td>"+ value[2] + "</td>\
                              <td>"+ value[3] + "</td>\
                              <td>"+ value[4] + "</td>\
                              <td>"+ value[6] + "</td>\
                              <td>"+ value[7] + "</td>\
                              <td>"+ value[8] + "</td>\
                              <td>"+ value[9] + "</td>\
                              <td><a href='#' onclick='edit_data(this);' data-bs-toggle='modal' data-bs-target='#edit_model' id='row"+ count + "'>Edit</a></td>\
                          </tr>";
        dump = $("#td_data");
        dump.append(html_text);
      })
      }
      else{
        alert(responsed.error);
      }
      $('#total').append(count);
      $('#total_liquid').append(liquid);
      var solid = count - liquid;
      $('#total_solid').append(solid);
    }
  })
});


function edit_data(ele) {
  var id = this.event.target.id;
  var row = ele.parentNode.parentNode;
  document.getElementById("eproductcode").value = row.cells[1].innerHTML;
  document.getElementById("eproductname").value = row.cells[2].innerHTML;
  document.getElementById("eproductqty").value = row.cells[3].innerHTML;
  document.getElementById("eproductunitprice").value = row.cells[4].innerHTML;
  var gender = row.cells[5].innerHTML;

  if (gender === 'liquid') {
    document.getElementById("eliquid").checked = true;
  }
  else {
    document.getElementById("esolid").checked = true;
  }
  document.getElementById("eproductunitvalue").value = row.cells[6].innerHTML;
  document.getElementById("eproductunituse").value = row.cells[7].innerHTML;
  document.getElementById("eproductexpire").value = row.cells[8].innerHTML;

}


// search date

$(document).on('submit', '#search_date_form', function (e) {
  e.preventDefault();
  $.ajax({
    type: 'POST',
    url: "search_data/",
    content_type: "application/json",
    data:
    {
      searchbox: $("#datesearchbox").val(),
      csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
    },
    success: function (responsed) {
      console.log(responsed)
      var count = 0;
      $('#td_data').empty();
      $('#total').empty();
      $('#total_liquid').empty();
      $('#total_solid').empty();
      var liquid = 0;
      if (responsed.error.localeCompare('None') == 0) {
        $.each(responsed.result_data, function (index, value) {
          if (value[6].localeCompare('liquid') == 0) {
            liquid = liquid + 1;
          }

          count = count + 1;
          html_text = "<tr>\
                              <td>"+ count + "</td>\
                              <td>"+ value[1] + "</td>\
                              <td>"+ value[2] + "</td>\
                              <td>"+ value[3] + "</td>\
                              <td>"+ value[4] + "</td>\
                              <td>"+ value[6] + "</td>\
                              <td>"+ value[7] + "</td>\
                              <td>"+ value[8] + "</td>\
                              <td>"+ value[9] + "</td>\
                              <td><a href='#' onclick='edit_data(this);' data-bs-toggle='modal' data-bs-target='#edit_model' id='row"+ count + "'>Edit</a></td>\
                          </tr>";
          dump = $("#td_data");
          dump.append(html_text);
        })
      }
      else {
        alert(responsed.error);
      }
      $('#total').append(count);
      $('#total_liquid').append(liquid);
      var solid = count - liquid;
      $('#total_solid').append(solid);
    }
  })
});