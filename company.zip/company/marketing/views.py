from django.shortcuts import render, HttpResponse, redirect
from .models import Mrkt_client
from datetime import datetime
from django.db.models import Q
import json
from django.core.serializers.json import DjangoJSONEncoder
from crmemail.pyemail import text_mail
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required(login_url='/')

def marketing(request):
    data = Mrkt_client.objects.filter(date=datetime.now().date()).values_list()
    name = []
    email = []
    phone = []
    status = []
    count = list(range(len(data)))
    dic = {}
    if data != '':
        for i in data:
            name.append(i[1])
            email.append(i[2])
            phone.append(i[3])
            status.append(i[4])
        dic = {'data':zip(name,email, phone,status,count), 'total':len(data)}
    return render(request, 'marketing/marketing.html', dic)




def marketing_form(request):
    return render(request, 'marketing/marketingform.html', {'message': ""})



def mart_form_data(request):
    name = request.POST['clientname']
    email = request.POST['clientemail']
    phone = request.POST['clientnumber']
    
    result = text_mail("Thanks for Showing intrest in sacleschool.", "Thank you "+name+" for showing intrest in scaleschool. We will contact you as soon as possible.", [email])
    if result == False:
        messages.error(request, "Invalid email id")
    else:
        new_client = Mrkt_client(name=name, email=email, phone=phone)
        new_client.save()
        messages.success(request, "Form submmitted Successfully!")
    return redirect('marketing_form')



@login_required(login_url='/')

def edit_status(request):
    name = request.POST['ename']
    email = request.POST['ceemail']
    phone = request.POST['ephone']
    status = request.POST['status']
    if Mrkt_client.objects.filter(email=email, phone=phone).count() != 0:
        print("enter")
        Mrkt_client.objects.filter(name=name, email=email, phone=phone).update(status=status)
        return redirect('marketing')
    else:
        return redirect('marketing')



@login_required(login_url='/')

def search_data(request):

    if request.method == "POST":
        data = request.POST["searchbox"]
        if data != 'all':
            
            result = Mrkt_client.objects.filter(
            Q(name__contains=data) | 
            Q(email__contains=data) | 
            Q(phone__contains=data) | 
            Q(status__contains=data) |
            Q(date__contains=data)).values_list()
            dumpdata = []
            if len(result) != 0:
                for data in result:
                    dumpdata.append(list(data))
                dic = {'result_data':dumpdata, 'error':'None'}
            else:
                dic = {'error': "No data found!"}
        else:
            alldata = list(Mrkt_client.objects.all().values_list())
            if len(alldata) !=0:
                dic = {'result_data':alldata, 'error':'None'}
            else:
                dic = {'error': "No data found!"}
    return HttpResponse(json.dumps(dic, cls=DjangoJSONEncoder), content_type="application/json")