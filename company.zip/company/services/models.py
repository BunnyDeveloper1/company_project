from django.db import models

# Create your models here.
class Add_service(models.Model):
    service_code = models.CharField(max_length=20, default="None", primary_key=True)
    service_name = models.CharField(max_length=20, default="None")
    service_product = models.CharField(max_length=500, default="None")
    service_price = models.CharField(max_length=20, default="None")
    def __str__(self):
        return self.service_name



class Add_package(models.Model):
    package_code = models.CharField(max_length=20, default="None", primary_key=True)
    package_name = models.CharField(max_length=20, default="None")
    package_services = models.CharField(max_length=500, default="None")
    package_price = models.CharField(max_length=20, default="None")
    def __str__(self):
        return self.package_name
