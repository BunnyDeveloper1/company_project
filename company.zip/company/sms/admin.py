from django.contrib import admin
from .models import SenderId, TemplateId
# Register your models here.
admin.site.register(SenderId)
admin.site.register(TemplateId)
