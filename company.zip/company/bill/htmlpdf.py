from io import BytesIO
from django.template.loader import get_template
import xhtml2pdf.pisa as pisa
from django.conf import settings

def save_pdf(params:dict,filename):
    template = get_template("bill/email_print_bill.html")
    print(filename)
    html = template.render(params)
    response = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode('UTF-8')), response)
    try:
        with open(str(settings.MEDIA_ROOT) + f'/pdffile/'+filename+'.pdf', 'wb+') as output:
            pdf = pisa.pisaDocument(BytesIO(html.encode('UTF-8')), output)
    except Exception as e:
        print("erroe")
    if pdf.err:
        return '', False
    
    return filename, True 

def save_pdf_thermal(params:dict,filename):
    template = get_template("bill/thermal_print.html")
    html = template.render(params)
    response = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode('UTF-8')), response)
    try:
        with open(str(settings.MEDIA_ROOT) + f'/pdffile/'+filename+'.pdf', 'wb+') as output:
            pdf = pisa.pisaDocument(BytesIO(html.encode('UTF-8')), output)
    except Exception as e:
        print("erroe")
    if pdf.err:
        return '', False
    
    return filename, True 


