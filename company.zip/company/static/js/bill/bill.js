var i = 1;
var j = 1;
let code = [];
let namepro = [];
let price = [];
let datacollect = [];

// add row data 
function createtr(value) {
    return '<td>' + i + '</td><td><select class="sel' + i + '" id="itemCode' + i + '" name = "productcode" style="width:100px;" disabled></select></td><td> <select   id="itemName' + i + '" name="productname" onclick="select_item(this,' + i + ');" style="width:200px;"></select></td><td><select class="sel' + i + '" id="unitprice' + i + '" name="productunit" style="width:80px;" disabled></select></td><td><input onclick="cal_total(this, ' + i + ')" name="productqty" type="number" style="width:60px;"></td><td><label id="total' + i + '"  name="producttotal" style="width:60px;"></label></td>' +
        '<a href="#" onclick = "RemoveTextBox(this)">Delete</a>'
}

// add row and dropdown values
function add_td() {
    var div = document.createElement('tr');
    div.setAttribute('id', 'tr' + j);
    div.innerHTML = createtr("");
    document.getElementById("add_item").appendChild(div);


    selectboxcode = document.getElementById("itemCode" + i);
    selectboxcode.options.length = 0;

    select_box_item = document.getElementById("itemName" + i);
    select_box_item.options.length = 0;



    for (let i = 0; i < datacollect.length; i++) {
        var option = document.createElement("option");
        option.value = i;
        option.text = datacollect[i][0];
        selectboxcode.add(option);
    }


    for (let i = 0; i < datacollect.length; i++) {
        var option = document.createElement("option");
        option.value = i;

        option.text = datacollect[i][1];
        select_box_item.add(option);
    }

    select_box_price = document.getElementById("unitprice" + i);
    select_box_price.options.length = 0;



    for (let i = 0; i < datacollect.length; i++) {
        var option = document.createElement("option");
        option.value = i;
        option.text = datacollect[i][2];
        select_box_price.add(option);
    }

    console.log("add", j)
    i = i + 1;
    j = j + 1;
}

// remove the row 
function RemoveTextBox(div) {
    document.getElementById("add_item").removeChild(div.parentNode);
    i = i - 1;
    j = j - 1;
    console.log("remove", j)
}

// change all select option on change name 
function select_item(id, id2) {
    var selectvalue = $(id).val();

    id2 = ".sel" + id2
    $(function () {
        $(id).on("change", function () { // or .sel for all
            $(id2).not(this).val(this.value);
        });
    });
}

// get value of unit price and give total price of a row
function cal_total(id, id2) {
    sel = "unitprice" + id2;

    var unitp = $("#" + sel + " option:selected").text();
    unit = unitp;

    $(function () {
        $(id).on("change", function () { // or .sel for all
            var qty = $(id).val();
            total_price = qty * unit;
            console.log(total_price);
            $("#total" + id2).text(total_price);
        });
    });
}

// find discount
function discount(sums) {
    let dict = document.getElementById("dicount_tb").value;
    let dict_val = (parseInt(dict) * sums) / 100;
    return parseInt(sums) - dict_val;
}

// find gst
function gst_total(sumst) {
    let perct = document.getElementById("gst_tb").value;
    let pert = parseInt(perct);
    let percent = (pert * sumst) / 100;
    return sumst + percent;

}

// find vocher
function vocher_total(sumsgst) {
    let vocher = document.getElementById("voucher_tb").value;
    let intvocher = parseInt(vocher);
    return sumsgst - intvocher
}

// get row cell value and add them
function get_total() {
    let sums = 0;
    var tbl = document.getElementById("add_item");
    var numRows = tbl.rows.length;
    
    if( numRows != 0){
        for (var i = 0; i < numRows; i++) {

            var cell = tbl.rows[i].cells[5].innerText;
            sums = sums + parseInt(cell);

        }
        document.getElementById("toal_value").innerHTML = sums
        // get gst
        dict_value = discount(sums);
        gst_value = gst_total(dict_value);
        total_price = vocher_total(gst_value);
        document.getElementById("grand_total_val").innerHTML = total_price;
        document.getElementById("save_data").disabled = false;
        document.getElementById("mail_send").disabled = true;
        document.getElementById("print").disabled = true;
    }
    else{
        alert("Please enter some data!");
    }
}

// get all row data for send
var send_code = [];
var send_name = [];
var send_unit_price = [];
var send_qty = [];
var send_row_total = [];
var send_total = "";
var send_dict = "";
var send_gst = "";
var send_voucher = "";
var send_grand_total = "";

function get_row() {
    send_code = [];
    send_name = [];
    send_unit_price = [];
    send_qty = [];
    send_row_total = [];

    var tbl = document.getElementById("add_item");
    var numRows = tbl.rows.length;
    if(numRows !=0){
        for (let k = 0; k < numRows; k++) {
            var cells = tbl.rows[k].getElementsByTagName('td');
            for (var ic = 0, it = cells.length; ic < it; ic++) {
                if (ic == 1) {

                    var tdObject = $(cells[1]).find('option:selected');
                    
                    send_code.push(tdObject.text());

                }
                if (ic == 2) {
                    var tdObject = $(cells[2]).find('option:selected');
                    
                    send_name.push(tdObject.text());
                }
                if (ic == 3) {
                    var tdObject = $(cells[3]).find('option:selected');
                    
                    send_unit_price.push(tdObject.text());
                }
                if (ic == 4) {
                    var tdObject = $(cells[4]).find('input');

                    send_qty.push(tdObject.val());
                }
                if (ic == 5) {

                    send_row_total.push(cells[5].innerText);

                }

            }
        }
        // console.log(send_code)
        send_total = document.getElementById("toal_value").innerText;
        send_dict = document.getElementById("dicount_tb").value;
        send_gst = document.getElementById("gst_tb").value;
        send_voucher = document.getElementById("voucher_tb").value;
        send_grand_total = document.getElementById("grand_total_val").innerText;
        document.getElementById('print').style.pointerEvents="auto";
    }
    else{
        alert('Enter some data please!');
    }
        
    

}

// get dateand time
$(document).ready(function () {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;
    document.getElementById("datetime").innerText = "" + dateTime;
});


// get all value price name code
$(document).ready(function (e) {
    $.ajax({
        type: 'POST',
        url: "send_data/",
        content_type: "application/json",
        data:
        {

            csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            $.each(responsed, function (key, value) {
                if (key == "data") {
                    $.each(value, function (index, val) {
                        datacollect.push(val)
                    })
                }
            })


        }
    })
});

// send data to django for saving it

$(document).on("click", "#save_data", function (e) {
    var send_invoice_number = document.getElementById("invoicenumber").innerText;
    var send_client_email = document.getElementById("clientemail").value;
    var send_clitent_name = document.getElementById("clientname").value;
    var send_bill_date_time = document.getElementById("datetime").innerText;

    if (send_client_email != "" && send_clitent_name != "" && send_code != "" && send_name != "" && send_unit_price != "" && send_qty != "" && send_row_total != "" && send_total != "" && send_dict != "" && send_gst != "" && send_gst != "" && send_grand_total != "") {

        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: "get_data/",
            content_type: "application/json",
            data:
            {
                "invoice_number": send_invoice_number,
                "client_email": send_client_email,
                "clitent_name": send_clitent_name,
                "bill_date_time": send_bill_date_time,
                "send_code[]": send_code,
                "pname[]": send_name,
                "unitprice[]": send_unit_price,
                "qty[]": send_qty,
                "rowtotal[]": send_row_total,
                "total": send_total,
                "discount": send_dict,
                "gst": send_gst,
                "voucher": send_voucher,
                "grandtotal": send_grand_total,
                csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
            },
            success: function (responsed) {
                if(responsed["message"].localeCompare('Save')==0){
                    alert("Data Save Successfully!");
                    document.getElementById('print').disabled=false;
                }
                else{
                    alert("Data Not Save")
                }
                
            }
        })
    }
    else {
        alert("Please Fill All Fields!");
    }

});



// search the invoice

$(document).on('submit', '#search_form', function (e) {
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: "search_data/",
        content_type: "application/json",
        data:
        {
            searchbox: $("#searchbox").val(),
            csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            let count = 0;
            $("#td_data").empty();
            $("#addclient-tab").removeClass('active');
            $("#search-tab").addClass('active');

            if (responsed.error.localeCompare('None') == 0) 
            {
  
                    $.each(responsed.result_data, function (index, value) {

                        count = count + 1;
                        html_text = "<tr>\
                        <td>" + count + "</td>\
                        <td>" + value[0] + "</td>\
                        <td>" + value[1] + "</td>\
                        <td>" + value[2] + "</td>\
                        <td>" + value[3] + "</td>\
                        <td>" + value[4] + "</td>\
                        <td>" + value[5] + "</td>\
                        <td>" + value[6] + "</td>\
                        <td>" + value[7] + "</td>\
                        <td>" + value[8] + "</td>\
                        <td><a href='media/pdffile/"+value[0]+".pdf' %}' target='_black'>Edit</a></td>\
                        </tr>"

                        dump = $("#td_data");
                        dump.append(html_text);

                    })


                    $('#total').html(count);
                    count = 0;




            }
            else{
                alert(responsed.error);
            }
        }
    })
});


$(document).ready(function(){
    document.getElementById('save_data').disabled=true;
    document.getElementById('mail_send').disabled=true;
    document.getElementById('print').style.pointerEvents="none";
})

function printfun(){
    document.getElementById('mail_send').disabled=false;
}