$(document).on('submit', '#search_form', function (e) {
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: "search_data/",
        content_type: "application/json",
        data:
        {
            searchbox: $("#searchbox").val(),
            csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            let count = 0;
            let male = 0;
            let female = 0;
            $("#td_data").empty();
            $("#addclient-tab").removeClass('active');
            $("#search-tab").addClass('active');
            if (responsed.error.localeCompare('None') == 0) {
              
                    $.each(responsed.result_data, function (index, value) {

                        count = count + 1;
                        if (value[4] == "male") {
                            male = male + 1;
                        }
                        html_text = "<tr><td>" + count + "</td><td>" + value[0] + "</td><td>" + value[1] + "</td><td>" + value[2] + "</td><td>" + value[3] + "</td><td>" + value[4] + "</td><td><a href='#' onclick='edit_data(this);' data-bs-toggle='modal' data-bs-target='#edit_model' id='row" + count + "'>Edit</a>&nbsp;&nbsp;&nbsp;<a href='#'>Delete</a></td></tr>"

                        dump = $("#td_data");
                        dump.append(html_text);

                    })


                    $('#total').html(count);
                    female = count - male;
                    $('#total_male').html(male);
                    $('#total_female').html(female);
                    count = 0;

            }
            else{
                alert(responsed.error)
            }


        }
    })
});

function edit_data(ele) {
    var id = this.event.target.id;
    var row = ele.parentNode.parentNode;
    document.getElementById("eclientname").value = row.cells[1].innerHTML;
    document.getElementById("eclientemail").innerHTML = row.cells[2].innerHTML;
    document.getElementById("eclientemail").value = row.cells[2].innerHTML;
    document.getElementById("ephonenumber").value = row.cells[3].innerHTML;
    document.getElementById("eWhatsappnumber").value = row.cells[4].innerHTML;
    var gender = row.cells[5].innerHTML;

    if (gender === 'male') {
        document.getElementById("male").checked = true;
    }
    else {
        document.getElementById("female").checked = true;
    }

}


// voucher serach ajax

$(document).on('submit', '#voucher_search_form', function (e) {
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: "search_voucher_data/",
        content_type: "application/json",
        data:
        {
            searchbox: $("#vouchersearchbox").val(),
            csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            let count = 0;
            $("#td_data").empty();
            $("#addclient-tab").removeClass('active');
            $("#searchvoucher-tab").addClass('active');
            console.log(responsed.result_data);
            if (responsed.error.localeCompare('None') == 0) {
                $.each(responsed.result_data, function (index, value) {
                    count = count + 1;
                    html_text = "<tr>\
                        <td>"+ count + "</td>\
                        <td>"+ value[1] + "</td>\
                        <td>"+ value[2] + "</td>\
                        <td>"+ value[3] + "</td>\
                        <td><a href='#' onclick='edit_voucher_data(this);'  data-bs-toggle='modal' data-bs-target='#voucherModal' id='row" + count + "'>Edit</a></td>\
                        </tr>"

                    dump = $("#voucher_td_data");
                    dump.append(html_text);

                })
                $('#vouhertotal').html(count);
                count = 0;
            }
            else {
                alert(responsed.error)
            }
        }
    })
});


// edit voucher 
function edit_voucher_data(ele) {
    var id = this.event.target.id;
    var row = ele.parentNode.parentNode;
    document.getElementById("client-name").value = row.cells[1].innerHTML;
    document.getElementById("client-email").value = row.cells[2].innerHTML;
    document.getElementById("client-voucher").value = row.cells[3].innerHTML;

}