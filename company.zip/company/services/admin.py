from re import I
from django.contrib import admin
from .models import Add_package, Add_service
# Register your models here.
admin.site.register(Add_service)
admin.site.register(Add_package)
