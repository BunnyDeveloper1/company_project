$(document).ready(function() {
    var ctx = $("#chart-line");
    const d = new Date();
    let year = d.getFullYear();


    var total_earning_sum = JSON.parse(document.getElementById('total_earning_sum').textContent);
    total_earning_sum = total_earning_sum.replace('[', '')
    total_earning_sum = total_earning_sum.replace(']', '')
    total_earning_sum = total_earning_sum.split(',')


    var expenses_total_sum = JSON.parse(document.getElementById('expenses_total_sum').textContent);
    expenses_total_sum = expenses_total_sum.replace('[', '')
    expenses_total_sum = expenses_total_sum.replace(']', '')
    expenses_total_sum = expenses_total_sum.split(',')

    var myLineChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Jan", "Feb", "March", "April", "May", "June", "July", "August", "Sep", "Oct", "Nov", "Dec"],
            datasets: [{
                data: total_earning_sum,
                label: "Earning",
                borderColor: "#458af7",
                backgroundColor:'#458af7',
                fill: false
            },
            {
                data: expenses_total_sum,
                label: "Expenses",
                borderColor: "#FF0000",
                backgroundColor:'#FF0000',
                fill: false
            }]
        },
        options: {
            title: {
                display: true,
                text: 'Silksalon monthly earning graph bar ' + String(year) + ' (in thousand).'
            }
        }
    });
});