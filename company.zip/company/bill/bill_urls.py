from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.bill, name='bill'),
    path('send_data/',views.send_data, name='send_data'),
    path('get_data/',views.get_data, name='get_data'),
    path('search_data/',views.search_data, name='search_data'),
    path('email_invoice/',views.email_invoice, name='email_invoice'),
    path('autocompletdata/',views.autocompletdata, name='autocompletdata'),
    path('getvoucher/',views.getvoucher, name='getvoucher'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) 