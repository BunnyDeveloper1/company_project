from re import sub
from django.http import HttpResponse
from django.shortcuts import redirect, render
from crmemail import pyemail
from django.contrib.auth.decorators import login_required


# Create your views here.
@login_required(login_url='/')
def crmemail(request):
    return render(request, 'crmemail/crmemail.html')


@login_required(login_url='/')
def send_email(request):
    email = request.POST["cemail"]
    subject = request.POST['csubject']
    message = request.POST["cmsg"]
    filename =  request.FILES['filename']
    print(filename)
    if filename == '':
        pyemail.text_mail(subject, message, [email])
    else:
        print('runn........')
        result = pyemail.file_inmemory_email('test', 'heello', [email], filename)
        print(result)
    return redirect('crmemail')

