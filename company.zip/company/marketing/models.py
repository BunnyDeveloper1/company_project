from datetime import datetime
from django.db import models

# Create your models here.

class Mrkt_client(models.Model):
    name = models.CharField(max_length=20, default="None")
    email = models.EmailField(max_length=100, default="None")
    phone = models.IntegerField(default="None")
    status = models.CharField(max_length=10, default='start')
    date = models.DateField(datetime.now().date(),default=datetime.now().date())

    def __str__(self):
        return self.name