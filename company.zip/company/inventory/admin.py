from django.contrib import admin
from .models import Add_product,Add_Catagories
# Register your models here.
admin.site.register(Add_product)
admin.site.register(Add_Catagories)