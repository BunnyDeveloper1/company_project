from django.db import models

# Create your models here.
class Invoice(models.Model):

    invoice = models.IntegerField(primary_key=True)
    client_email = models.EmailField()
    client_name = models.CharField(max_length=40)
    date = models.DateTimeField()
    total = models.FloatField()
    discount = models.FloatField()
    gst = models.FloatField()
    voucher = models.FloatField(default=0)
    grand_total = models.FloatField()
    def __str__(self):
        return str(self.invoice)

class Bill(models.Model):

    invoice = models.IntegerField()
    code = models.CharField(max_length=10)
    product_name = models.CharField(max_length=80)
    unitprice = models.IntegerField()
    qty = models.IntegerField()
    total = models.IntegerField()

    def __str__(self):
        return str(self.invoice)
