from django.urls import path
from . import views
urlpatterns = [
    path("", views.inventory, name='inventory'),
    path("add_product/", views.add_product, name='add_product'),
    path("get_data/", views.get_data, name='get_data'),
    path("add_categorie/", views.add_categorie, name='add_categorie'),   
    path("search_data/", views.search_data, name='search_data'),   
]