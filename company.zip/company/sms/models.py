from django.db import models

# Create your models here.
class SenderId(models.Model):

    sendid = models.CharField(max_length=8, default="None")

    def __str__(self):
        return self.sendid


class TemplateId(models.Model):

    message_id = models.CharField(max_length=8, default="None")
    template = models.CharField(max_length=200, default="None")

    def __str__(self):
        return self.message_id