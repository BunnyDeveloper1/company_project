from django.shortcuts import redirect, render, HttpResponse
import json
from .models import Add_client,Add_voucher
from django.db.models import Q
from django.contrib import messages
from django.contrib.auth.decorators import login_required


# Create your views here.
@login_required(login_url='/')
def client(request):
    total_client = Add_client.objects.all().count()
    female_client = Add_client.objects.filter(client_gender='female').count()
    male_client = total_client - female_client
    dic = {'total': total_client, 'total_female':female_client, 'total_male':male_client}
    return render(request, 'client/client.html', dic)


@login_required(login_url='/')
def add_client(request):

    client_name = request.POST['cname']
    client_email = request.POST['cemail']
    client_phone_num = request.POST['cphone']
    client_whatsapp_num = request.POST['cwhatsapp']
    client_gender = request.POST['cgender']
    if client_whatsapp_num == '':
        client_whatsapp_num = 0

    new_client =  Add_client(client_name=client_name, client_email=client_email,client_phone_number=client_phone_num,client_whatsapp_number=client_whatsapp_num,client_gender = client_gender)
    new_client.save()
    messages.success(request, 'Client Data save successfully!')
    return redirect('client')


@login_required(login_url='/')
def search_data(request):

    if request.method == "POST":
        data = request.POST["searchbox"]
        if data != 'all':
            result = Add_client.objects.filter(

            Q(client_name__contains=data) | 
            Q(client_email__contains=data) | 
            Q(client_phone_number__contains=data) | 
            Q(client_whatsapp_number__contains=data) | 
            Q(client_gender__contains=data)).values_list()

            dumpdata = []
            if len(result) != 0:
                for data in result:
                    dumpdata.append(list(data))
                dic = {'result_data':dumpdata, 'error':'None'}
            else:
                dic = {'error': "No data found!"}
        else:
            alldata = list(Add_client.objects.all().values_list())
            if len(alldata) !=0:
                dic = {'result_data':alldata, 'error':'None'}
            else:
                dic = {'error': "No data found!"}
    return HttpResponse(json.dumps(dic), content_type="application/json")


@login_required(login_url='/')
def edit_client(request):

    if request.method == "POST":
        ename = request.POST["ename"]
        emails = request.POST["ueemail"]
        phone = request.POST["ephone"]
        whatsapp = request.POST["ewhatsapp"]
        egender = request.POST["egender"]
        if Add_client.objects.filter(client_email = emails).exists():
            Add_client.objects.filter(client_email=emails).update(client_name=ename, client_email =emails, client_phone_number = phone, client_whatsapp_number = whatsapp, client_gender = egender)
            return redirect('client')
        else:
            return HttpResponse("")



@login_required(login_url='/')
def search_voucher_data(request):
    query = request.POST['searchbox']
    if query != "all":
        result = Add_voucher.objects.filter(Q(client_name__contains=query) | Q(client_email__contains=query) | 
                Q(client_voucher_balance__contains=query)).values_list()
        dumpdata = []
        if len(result) != 0:
            for data in result:
                dumpdata.append(list(data))

            dic = {'result_data':dumpdata, 'error':'None'}
        else:
            dic = {'error': "No data found!"}
    else:
        alldata = list(Add_voucher.objects.all().values_list())
        if len(alldata) !=0:
            dic = {'result_data':alldata, 'error':'None'}
        else:
            dic = {'error': "No data found!"}
    return HttpResponse(json.dumps(dic), content_type="application/json")


@login_required(login_url='/')
def edit_voucher(request):
    if request.method == "POST":
        ename = request.POST["ecname"]
        emails = request.POST["ecemail"]
        voucher = request.POST["ecvoucher"]
        if Add_voucher.objects.filter(client_email = emails).exists():
            Add_voucher.objects.filter(client_email=emails).update(client_name=ename, client_email =emails, client_voucher_balance=voucher)
            messages.success(request, 'Voucher Data edit success fully')
            return redirect('client')
        else:
            return HttpResponse("")