"""company URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from marketing import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('user_authentication.auth_urls')),
    path('dashboard/', include('dashboard.dashboard_urls')),
    path('marketing_form/', views.marketing_form, name="marketing_form"),
    path('mart_form_data/', views.mart_form_data, name="mart_form_data"),
    path('client/', include('client.client_urls')),
    path('services/', include('services.services_urls')),
    path('inventory/', include('inventory.inventory_urls')),
    path('bill/', include('bill.bill_urls')),
    path('marketing/', include('marketing.marketing_urls')),
    path('crmemail/', include('crmemail.email_urls')),
    path('expenses/', include('expenses.expenses_urls')),
    path('sms/', include('sms.sms_urls')),
]
