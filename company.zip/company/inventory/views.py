from django.shortcuts import redirect, render, HttpResponse
from .models import Add_product, Add_Catagories
import json
from django.db.models import Q
from django.core.serializers.json import DjangoJSONEncoder
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required(login_url='/')

def inventory(request):
    return render(request, 'inventory/inventory.html')


@login_required(login_url='/')

def add_product(request):

    productcode = request.POST['productcode']
    productcode = "PROD"+productcode
    productname = request.POST['productname']
    productqty = request.POST['productqty']
    productunitprice = request.POST['productprice']
    producttotalprice= int(productunitprice) * int(productqty) 
    producttype = request.POST['producttype']
    productunitvalue = request.POST['productvalue']
    productunituse = request.POST['productuse']
    productexpire = request.POST['productexpire']
    if Add_product.objects.filter(product_code=productcode).exists():
        messages.error(request, "Product Data Already Exits!")
    else:
        new_product = Add_product(product_code = productcode, product_name = productname, product_qty=productqty, product_unit_price=productunitprice, product_total_price=producttotalprice, product_type=producttype, product_unit_value=productunitvalue, product_unit_use=productunituse, product_expi_date=productexpire)
        new_product.save()
        messages.error(request, "Product Data Save Successfully!")
    return redirect('inventory')



@login_required(login_url='/')

def get_data(request):
    code = Add_product.objects.values_list('product_code', flat=True)
    name = Add_product.objects.values_list('product_name', flat=True)
    catagories = list(Add_Catagories.objects.all().values())
    dic = []
    send_data ={}
    for i,v in enumerate(code):
        zip_data = (v, name[i])
        dic.append(zip_data)
    send_data["list"] = dic
    pcode = []
    pname = []
    pqty = []
    temp = []
    catagory = {}
    send_list = []
    for i in catagories:
        prod_list =  json.loads(i['product_lists'])

        for k in prod_list:
            k = k.replace("'", "")
            result = Add_product.objects.filter(product_code=k).values()[0]
            pcode.append(result['product_code'])
            pname.append(result['product_name'])
            pqty.append(result['product_qty'])
            catagory['catagorie_name'] = i['catagorie_name']
        
        for k,v in enumerate(pcode):
            zip_data = (v, pname[k], pqty[k])
            temp.append(zip_data)
            
        catagory['data_list'] = temp
        pcode = []
        pname = []
        pqty = []
        temp = []
        send_list.append(catagory)
        catagory = {}
    
    send_data['catagories']=send_list
    return HttpResponse(json.dumps(send_data), content_type="application/json")


@login_required(login_url='/')

def add_categorie(request):
    if request.method == "POST":
        catagorie_name = request.POST['categoriename']
        product_code = request.POST.getlist('itemcode')
        code_list = [ i.replace('/', '') for i in product_code if '/' in i ]
        code_list = ",".join( repr(e) for e in code_list )
        code_list = code_list.split(",")
        new_catagorie = Add_Catagories(catagorie_name=catagorie_name, product_lists=json.dumps(code_list))
        new_catagorie.save()
        messages.success(request, "Data Save successfully!")
        return redirect('inventory')
    else:
        return redirect('inventory')



@login_required(login_url='/')

def search_data(request):
    if request.method == "POST":
        query = request.POST['searchbox']
        if query != "all":
            result = Add_product.objects.filter(Q(product_code__contains=query) | 
            Q(product_name__contains=query) | 
            Q(product_qty__contains=query) | 
            Q(product_unit_price__contains=query) | 
            Q(product_total_price__contains=query) | 
            Q(product_type__contains=query) |
            Q(product_unit_value__contains=query) | 
            Q(product_unit_use__contains=query) |
            Q(product_expi_date__contains=query)).values_list()
            dumpdata = []
            if len(result) !=0:
                for data in result:
                    dumpdata.append(list(data))
                dic = {'result_data':dumpdata, 'error':"None"}
            else:
                dic = {'error':'Data Not Found!'}

            return HttpResponse(json.dumps(dic, cls=DjangoJSONEncoder), content_type="application/json")
        else:
            alldata = list(Add_product.objects.all().values_list())
            if len(alldata) != 0:
                dic = {'result_data':alldata, "error":"None"}
            else:
                dic = {'error':'Data Not Found!'}
            return HttpResponse(json.dumps(dic, cls=DjangoJSONEncoder), content_type="application/json")
    return redirect('inventory')




@login_required(login_url='/')

def edit_product(request):

    if request.method == "POST":
        eproductcode = request.POST["eproductcode"]
        eproductname = request.POST["eproductname"]
        eproductqty = request.POST["eproductqty"]
        eproductunitprice = request.POST["eproductunitprice"]
        eproducttype = request.POST["producttype"]
        eproductunitvalue = request.POST["eproductunitvalue"]
        eproductunituse = request.POST["eproductunituse"]
        eproductexpire = request.POST["eproductexpire"]

        if Add_product.objects.filter(product_code = eproductcode).exists():
            Add_product.objects.filter(product_code=eproductcode).update(product_name=eproductname, product_qty =eproductqty, product_unit_price = eproductunitprice, product_type = eproducttype,  product_unit_value= eproductunitvalue, product_unit_use=eproductunituse, product_expi_date=eproductexpire)
            return redirect('client')
        else:
            return HttpResponse("")