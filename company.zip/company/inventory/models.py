from ast import mod
from django.db import models

# Create your models here.
class Add_product(models.Model):

    product_code = models.CharField(max_length=20 ,default='None', primary_key=True)
    product_name = models.CharField(max_length=40, default='None')
    product_qty = models.IntegerField(default='None')
    product_unit_price = models.IntegerField(default='None')
    product_total_price = models.IntegerField(default='None')
    product_type = models.CharField(max_length=10 ,default='None')
    product_unit_value = models.IntegerField(default='None')
    product_unit_use = models.IntegerField(default='None')
    product_expi_date = models.DateField(default='None')

    def __str__(self):
        return self.product_name

class Add_Catagories(models.Model):

    catagorie_name = models.CharField(max_length=50, default="None", primary_key=True)
    product_lists = models.CharField(max_length=50, default="None")

    def __str__(self):
        return self.catagorie_name