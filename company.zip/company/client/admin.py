from django.contrib import admin
from .models import Add_client,Add_voucher,Add_voucher_range
# Register your models here.
admin.site.register(Add_client)
admin.site.register(Add_voucher)
admin.site.register(Add_voucher_range)

