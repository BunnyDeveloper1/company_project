from django.contrib import admin
from .models import Invoice,Bill
# Register your models here.
admin.site.register(Invoice)
admin.site.register(Bill)
