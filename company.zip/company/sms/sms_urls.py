from django.urls import path
from . import views

urlpatterns = [
    path('', views.sms, name='sms'), 
    path('sender_id/', views.save_sender_id, name='save_sender_id'), 
    path('template_id/', views.template_id, name='template_id'), 
    path('send_sms/', views.send_sms, name='send_sms'), 
]


