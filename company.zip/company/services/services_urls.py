from django.urls import path
from . import views
urlpatterns = [
    path('',  views.services, name='services'),
    path('add_service/',  views.add_service, name='add_service'),
    path('add_package/',  views.add_package, name='add_package'),
    path('product_list/',  views.product_list, name='product_list'),
    path('service_list/',  views.service_list, name='service_list'),
    path('search_data/',  views.search_data, name='search_data'),
    path('edit_service/',  views.edit_service, name='edit_service'),
]