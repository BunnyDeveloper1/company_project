// ajax for geting a list of product
$(document).ready(function (e) {
    // e.preventDefault();
    $.ajax({
        type: 'POST',
        url: "product_list/",
        content_type: "application/json",
        data:
        {
            csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            $("#serviceproduct").empty();
            // this  each loop for product list
            dump = $('#serviceproduct');
            dump.append('<div class="row"><div class="col">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Code</b></div><div class="col"><b>Name</b></div>');
            $.each(responsed.list, function (response, value) {
                val1 = value[0];
                val2 = value[1];
                dump = $('#serviceproduct');
                dump.append('<div class="row"><div class="col"><input type="checkbox" name="itemcode" value=' + val1 + '/> &nbsp;&nbsp;&nbsp;&nbsp;' + val1 + '</div><div class="col">' + val2 + '</div>');
            }
            )
        }
    })
});



// ajax for getting list of service
$(document).on('click', '#addpackage-tab', function (e) {
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: "service_list/",
        content_type: "application/json",
        data:
        {
            csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            $("#packageitems").empty();
            $("#addservice-tab").removeClass('active');
            $("#addpackage-tab").addClass('active');
            // this  each loop for product list
            dump = $('#packageitems');
            dump.append('<div class="row"><div class="col">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Code</b></div><div class="col"><b>Name</b></div>');
            $.each(responsed.list, function (response, value) {
                val1 = value[0];
                val2 = value[1];
                dump = $('#packageitems');
                dump.append('<div class="row"><div class="col"><input type="checkbox" name="itemcode" value=' + val1 + '>&nbsp;&nbsp;&nbsp;&nbsp;' + val1 + '</div><div class="col">' + val2 + '</div>');
            }
            )
        }
    })
});



// search the product 
$(document).on('submit', '#search_form', function (e) {
    e.preventDefault();
    $.ajax({
        type: 'POST',
        url: "search_data/",
        content_type: "application/json",
        data:
        {
            searchbox: $("#searchbox").val(),
            csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            var count = 0;
            $('#td_data').empty();
            $('#total').empty();
            $('#total_service').empty();
            $('#total_package').empty();
            $.each(responsed.result_data, function (index, value) {

                var sertype = value[1];
        
                if(sertype.substring(0,3).localeCompare('SVC')==0){
                    sertype = 'Service';
                }
                else{
                    sertype = 'Package';
                }

                count = count + 1;
                html_text = "<tr>\
                                <td>"+ count + "</td>\
                                <td>"+ value[1] + "</td>\
                                <td>"+ value[2] + "</td>\
                                <td>"+ value[3] +"</td>\
                                <td>"+ value[4] + "</td>\
                                <td>"+ sertype + "</td>\
                                <td><a href='#' onclick='edit_data(this);' data-bs-toggle='modal' data-bs-target='#edit_model' id='row"+ count + "'>Edit</a></td>\
                            </tr>";
                dump = $("#td_data");
                dump.append(html_text);
            })

            $('#total').append(responsed.package_count + responsed.service_count);
            $('#total_service').append(responsed.service_count);
            $('#total_package').append(responsed.package_count);
        }
    })
});


function edit_data(ele){
    var id = this.event.target.id;
    var row = ele.parentNode.parentNode;
    document.getElementById("code").value = row.cells[1].innerHTML;
    document.getElementById("name").value = row.cells[2].innerHTML;
    document.getElementById("servpro").value = row.cells[3].innerHTML;
    document.getElementById("price").value = row.cells[4].innerHTML;
    document.getElementById("type").value = row.cells[5].innerHTML;
    

}

