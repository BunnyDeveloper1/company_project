$(document).on('click', "ssenderid", function(e){
    e.preventDefault()
    $.ajax({
        type: 'POST',
        url: "autocompletdata/",
        content_type: "application/json",
        data:
        {
          clientemail: $("#clientemail").val(),
          csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function (responsed) {
            
        }
    })
})