from django.urls import path,include
from . import views
urlpatterns = [
    path('', views.expenses, name="expenses"),
    path('save_expenses/', views.save_expenses, name="save_expenses"),
]