from statistics import mode
from django.db import models
from datetime import datetime
# Create your models here.
class Expenses(models.Model):

    expenses_name = models.CharField(max_length=100, default="None")
    expenses_cost = models.IntegerField(default=0)
    date = models.DateField(default=datetime.today().now())

    def __Str__(self):
        return self.expenses_name