from django.urls import path
from . import views
urlpatterns = [
    path('', views.marketing, name='marketing'),
    path('edit_status/', views.edit_status, name='edit_status'),
    path('search_data/', views.search_data, name='search_data'),
]